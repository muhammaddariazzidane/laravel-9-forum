@extends('layouts.main')

@section('content')
    teknologi : laravel 9, laravel breeze, laravel socialite , tailwindcss, alpine js, laravel-notify, turbo-laravel, font
    awesome 5,
@endsection
