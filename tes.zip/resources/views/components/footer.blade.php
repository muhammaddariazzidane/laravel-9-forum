<footer class="max-w-xs mx-auto pt-4 pb-10 mt-20">
    <div class="flex p-2 justify-center gap-x-3 mx-auto">
        <div>
            <i class="fab fa-github text-gray-300 text-3xl"></i>
        </div>
        <div>
            <i class="fab fa-youtube text-red-700 text-3xl"></i>
        </div>
        <div>
            <i class="fab fa-facebook text-blue-700 text-3xl"></i>
        </div>
        <div>
            <i
                class="fab fa-instagram bg-gradient-to-br from-indigo-400 via-red-600 to-yellow-600 bg-clip-text text-transparent text-3xl"></i>
        </div>
    </div>
    <div class="text-gray-400 mt-3 text-center ">
        <p>Dariaz zidane • © 2023 • All rights reserved</p>
    </div>
</footer>
