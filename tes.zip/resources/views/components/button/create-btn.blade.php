<button role="button" @click="modelOpen =!modelOpen"
    class="flex items-center justify-center px-3 py-2 space-x-2 text-sm tracking-wide text-white capitalize transition-colors duration-200 transform bg-teal-500 rounded-md dark:bg-teal-700 dark:hover:bg-teal-700 dark:focus:bg-teal-700 hover:bg-teal-600 focus:outline-none focus:bg-teal-500 focus:ring focus:ring-teal-300 focus:ring-opacity-50">
    <i class="fas fa-plus"></i>

    <span>add post</span>
</button>
