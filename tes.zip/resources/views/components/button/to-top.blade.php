{{-- <a href="#comment" id="topButton2"
    class="fixed z-10 scale-0 p-2 px-[0.75rem] bg-teal-400 rounded-full shadow-md bottom-16 mb-8 right-10 transition-all duration-500">
    <i class="fas fa-comment-dots text-xl"></i>
</a> --}}
<button x-data="topBtn" @click="scrolltoTop" id="topButton"
    class="fixed z-10 scale-0 p-2 px-[0.85rem] bg-teal-400 rounded-full shadow-md bottom-10 right-10 transition-all duration-500">
    <i class="fas fa-chevron-up text-xl"></i>
</button>
