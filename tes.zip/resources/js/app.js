import "./bootstrap";
import "./elements/turbo-echo-stream-tag";
import "./libs/turbo";

import Alpine from "alpinejs";

window.Alpine = Alpine;

Alpine.start();
